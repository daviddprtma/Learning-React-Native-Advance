export const DATA = [
    {
    id: "1",
    nama: "Semur Tuna Beraroma",
    desk:"Semur Tuna Beraroma satu lagi resep andalan Dapur Bango. Ikan tuna segar dibumbui kunyit, pandan, daun kemangi dan daun bawang disajikan dengan siraman kuah semur yang lezat meresap...oh, sungguh nikmat disantap! ",
    photo:"https://assets.unileversolutions.com/recipes-v3/242582-default.jpg"
    },
    {
    id: "2",
    nama: "Udang Saos Tiram",
    desk:"Lengkapi santap malam seafood dengan resep udang saus tiram yang satu ini. Lezat dan istimewa, ternyata cara memasak udang saus tiram tidaklah sulit dan membutuhkan waktu yang terlalu lama. ",
    photo:"https://assets.unileversolutions.com/recipes-v3/242813-default.jpg"
    },
    {
    id: "3",
    nama: "Semur Perkedel Ikan",
    desk:"Resep Semur Perkedel Ikan dari Banten lezatnya memanjakan lidah kita. Rasa perpaduan adonan kentang dan ikan tuna dengan kelapa parut yang unik membuat kita ingin nambah lagi dan lagi. Yuk coba! ",
    photo:"https://assets.unileversolutions.com/recipes-v3/242766-default.jpg"
    },
    ];